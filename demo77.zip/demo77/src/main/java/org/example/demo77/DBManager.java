package org.example.demo77;

import org.mindrot.jbcrypt.BCrypt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBManager {
    private static final String URL = "jdbc:sqlite:calculator.db";

    public static void init() {
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {

            // 1. Создание таблицы пользователей
            String sqlUsers = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "username TEXT NOT NULL UNIQUE," +
                    "password_hash TEXT NOT NULL," +
                    "role TEXT NOT NULL DEFAULT 'USER')";
            stmt.execute(sqlUsers);

            // 2. Создание таблицы истории
            String sqlHistory = "CREATE TABLE IF NOT EXISTS history (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "user_id INTEGER NOT NULL," +
                    "type TEXT NOT NULL," +
                    "inputs TEXT NOT NULL," +
                    "result TEXT NOT NULL," +
                    "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP," +
                    "FOREIGN KEY (user_id) REFERENCES users(id))";
            stmt.execute(sqlHistory);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Database initialization failed", e);
        }
    }

    public static boolean register(String username, String password, String role) {
        if (username.isEmpty() || password.isEmpty()) return false;

        try (Connection conn = DriverManager.getConnection(URL)) {
            // Проверка на существование пользователя
            String checkSql = "SELECT count(*) FROM users WHERE username = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, username);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    return false; // Пользователь уже существует
                }
            }

            // Хеширование пароля и регистрация
            String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
            String insertSql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, username);
                insertStmt.setString(2, hashed);
                insertStmt.setString(3, role);
                insertStmt.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static User login(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) return null;

        String sql = "SELECT id, password_hash, role FROM users WHERE username = ?";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String hashed = rs.getString("password_hash");
                if (BCrypt.checkpw(password, hashed)) {
                    int id = rs.getInt("id");
                    String role = rs.getString("role");
                    return new User(id, username, role);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void saveCalculation(User user, String type, String inputs, String result) {
        String sql = "INSERT INTO history (user_id, type, inputs, result) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, user.getId());
            pstmt.setString(2, type);
            pstmt.setString(3, inputs);
            pstmt.setString(4, result);
            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Метод для загрузки истории (используется в HistoryScene)
    public static ResultSet loadHistory(String username, String role) throws Exception {
        String sql;
        PreparedStatement pstmt;
        Connection conn = DriverManager.getConnection(URL);

        if (role.equals("ADMIN")) {
            sql = "SELECT h.*, u.username FROM history h JOIN users u ON h.user_id = u.id ORDER BY h.timestamp DESC";
            pstmt = conn.prepareStatement(sql);
        } else {
            sql = "SELECT h.* FROM history h JOIN users u ON h.user_id = u.id WHERE u.username = ? ORDER BY h.timestamp DESC";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
        }
        return pstmt.executeQuery();
    }
}