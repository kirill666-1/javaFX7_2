package org.example.demo77;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Alert; // <-- ИСПРАВЛЕННЫЙ ИМПОРТ

import java.sql.ResultSet;

public class HistoryScene {
    public static void show(Stage stage, User user) {
        VBox vbox = new VBox(10);
        TableView<HistoryEntry> table = new TableView<>();
        // ... (инициализация TableColumns) ...

        TableColumn<HistoryEntry, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        TableColumn<HistoryEntry, String> inputsCol = new TableColumn<>("Inputs");
        inputsCol.setCellValueFactory(new PropertyValueFactory<>("inputs"));
        TableColumn<HistoryEntry, String> resultCol = new TableColumn<>("Result");
        resultCol.setCellValueFactory(new PropertyValueFactory<>("result"));
        TableColumn<HistoryEntry, String> timeCol = new TableColumn<>("Timestamp");
        timeCol.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
        table.getColumns().addAll(typeCol, inputsCol, resultCol, timeCol);

        if (user.getRole().equals("ADMIN")) {
            TableColumn<HistoryEntry, String> userCol = new TableColumn<>("Username");
            userCol.setCellValueFactory(new PropertyValueFactory<>("username"));
            table.getColumns().add(userCol);
        }

        String username = user.getUsername();
        try (ResultSet rs = DBManager.loadHistory(username, user.getRole())) {
            while (rs.next()) {
                table.getItems().add(new HistoryEntry(
                        rs.getString("type"),
                        rs.getString("inputs"),
                        rs.getString("result"),
                        rs.getString("timestamp"),
                        user.getRole().equals("ADMIN") ? rs.getString("username") : username
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error loading history: " + e.getMessage());
            alert.show();
        }

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> MainMenuScene.show(stage, user));

        vbox.getChildren().addAll(table, backBtn);

        Scene scene = new Scene(vbox, 800, 400);
        stage.setTitle("History");
        stage.setScene(scene);
        stage.show();
    }

    public static class HistoryEntry {
        private final String type;
        private final String inputs;
        private final String result;
        private final String timestamp;
        private final String username;

        public HistoryEntry(String type, String inputs, String result, String timestamp, String username) {
            this.type = type;
            this.inputs = inputs;
            this.result = result;
            this.timestamp = timestamp;
            this.username = username;
        }

        public String getType() { return type; }
        public String getInputs() { return inputs; }
        public String getResult() { return result; }
        public String getTimestamp() { return timestamp; }
        public String getUsername() { return username; }
    }
}