package org.example.demo77;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainMenuScene {
    public static void show(Stage stage, User user) {
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);

        Button ohmBtn = new Button("Ohm's Law Calculator");
        Button dividerBtn = new Button("Voltage Divider Calculator");
        Button historyBtn = new Button("View History");
        Button logoutBtn = new Button("Logout");

        ohmBtn.setOnAction(e -> OhmScene.show(stage, user));
        dividerBtn.setOnAction(e -> DividerScene.show(stage, user));
        historyBtn.setOnAction(e -> HistoryScene.show(stage, user));
        logoutBtn.setOnAction(e -> LoginScene.show(stage));

        vbox.getChildren().addAll(ohmBtn, dividerBtn, historyBtn, logoutBtn);

        Scene scene = new Scene(vbox, 300, 200);
        stage.setTitle("Main Menu - " + user.getUsername());
        stage.setScene(scene);
        stage.show();
    }
}