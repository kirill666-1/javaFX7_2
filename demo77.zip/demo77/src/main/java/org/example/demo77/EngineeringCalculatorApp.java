package org.example.demo77;

import javafx.application.Application;
import javafx.stage.Stage;

public class EngineeringCalculatorApp extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            // Инициализация базы данных
            DBManager.init();
            // Показ сцены входа
            LoginScene.show(primaryStage);
        } catch (Exception e) {
            e.printStackTrace();
            // В случае сбоя инициализации покажем ошибку
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.ERROR,
                    "Application failed to initialize: " + e.getMessage()
            );
            alert.showAndWait();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}