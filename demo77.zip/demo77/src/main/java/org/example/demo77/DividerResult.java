package org.example.demo77;

import java.util.List;

public class DividerResult {
    private final int numRes;
    private final List<Double> resistors;
    private final String config;
    private final double vout;
    private final double error;
    private final double power;

    public DividerResult(int numRes, List<Double> resistors, String config, double vout, double error, double power) {
        this.numRes = numRes;
        this.resistors = resistors;
        this.config = config;
        this.vout = vout;
        this.error = error;
        this.power = power;
    }

    // Getters (необходимы для TableView)
    public int getNumRes() { return numRes; }
    public List<Double> getResistors() { return resistors; }
    public String getConfig() { return config; }
    public double getVout() { return vout; }
    public double getError() { return error; }
    public double getPower() { return power; }
}