package org.example.demo77;

public class OhmCalculator {

    /**
     * Конвертирует значение в базовые единицы (V, A, Ohm).
     */
    private static double toBase(String param, double value, String unit) {
        if (param.equals("V")) {
            return value * (unit.equals("mV") ? 0.001 : 1);
        } else if (param.equals("I")) {
            return value * (unit.equals("mA") ? 0.001 : 1);
        } else { // R
            if (unit.equals("kOhm")) return value * 1000;
            if (unit.equals("MOhm")) return value * 1e6;
            return value;
        }
    }

    /**
     * Форматирует результат с соответствующей единицей.
     */
    private static String formatResult(double value, String type) {
        if (type.equals("R")) {
            if (value >= 1e6) return String.format("%.3f MOhm", value / 1e6);
            if (value >= 1000) return String.format("%.3f kOhm", value / 1000);
            return String.format("%.3f Ohm", value);
        }
        if (type.equals("V")) {
            if (value < 1.0) return String.format("%.3f mV", value * 1000);
            return String.format("%.3f V", value);
        }
        if (type.equals("I")) {
            if (value < 1.0) return String.format("%.3f mA", value * 1000);
            return String.format("%.3f A", value);
        }
        return String.format("%.3f", value);
    }

    public static String calculate(String p1, double v1, String u1, String p2, double v2, String u2) {
        double V = 0, I = 0, R = 0;

        // Определяем, какой параметр пропущен (используем только два)
        String missingParam = "";

        if (!p1.equals("V") && !p2.equals("V")) missingParam = "V";
        else if (!p1.equals("I") && !p2.equals("I")) missingParam = "I";
        else if (!p1.equals("R") && !p2.equals("R")) missingParam = "R";
        else throw new IllegalArgumentException("Parameters must be V, I, and R in total (two provided)");

        // Заполняем известные значения в базовых единицах
        if (p1.equals("V")) V = toBase("V", v1, u1);
        else if (p1.equals("I")) I = toBase("I", v1, u1);
        else R = toBase("R", v1, u1);

        if (p2.equals("V")) V = toBase("V", v2, u2);
        else if (p2.equals("I")) I = toBase("I", v2, u2);
        else R = toBase("R", v2, u2);

        // Расчет пропущенного параметра
        if (missingParam.equals("V")) {
            if (I == 0 || R == 0) throw new IllegalArgumentException("Cannot calculate V (I or R is zero)");
            V = I * R;
            return "V = " + formatResult(V, "V");
        }
        if (missingParam.equals("I")) {
            if (R == 0) throw new IllegalArgumentException("Cannot calculate I (R is zero)");
            I = V / R;
            return "I = " + formatResult(I, "I");
        }
        if (missingParam.equals("R")) {
            if (I == 0) throw new IllegalArgumentException("Cannot calculate R (I is zero)");
            R = V / I;
            return "R = " + formatResult(R, "R");
        }

        return "Calculation Error";
    }
}