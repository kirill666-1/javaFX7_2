package org.example.demo77;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class LoginScene {
    public static void show(Stage stage) {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);

        Label userLabel = new Label("Username:");
        TextField userField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        Button loginBtn = new Button("Login");
        Button regBtn = new Button("Register");

        grid.add(userLabel, 0, 0);
        grid.add(userField, 1, 0);
        grid.add(passLabel, 0, 1);
        grid.add(passField, 1, 1);
        grid.add(loginBtn, 1, 2);
        grid.add(regBtn, 1, 3);

        loginBtn.setOnAction(e -> {
            User user = DBManager.login(userField.getText(), passField.getText());
            if (user != null) {
                MainMenuScene.show(stage, user);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid credentials");
                alert.show();
            }
        });

        regBtn.setOnAction(e -> RegistrationScene.show(stage));

        Scene scene = new Scene(grid, 400, 300);
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }
}