package org.example.demo77;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class OhmScene {
    public static void show(Stage stage, User user) {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_LEFT);
        grid.setHgap(10);
        grid.setVgap(10);

        ChoiceBox<String> param1 = new ChoiceBox<>();
        param1.getItems().addAll("V", "I", "R");
        TextField value1 = new TextField();
        ChoiceBox<String> unit1 = new ChoiceBox<>();
        unit1.getItems().addAll("V", "mV", "A", "mA", "Ohm", "kOhm", "MOhm");

        ChoiceBox<String> param2 = new ChoiceBox<>();
        param2.getItems().addAll("V", "I", "R");
        TextField value2 = new TextField();
        ChoiceBox<String> unit2 = new ChoiceBox<>();
        unit2.getItems().addAll("V", "mV", "A", "mA", "Ohm", "kOhm", "MOhm");

        Button calcBtn = new Button("Calculate");
        Label resultLabel = new Label("Result: ");
        Button backBtn = new Button("Back");

        grid.add(new Label("Param 1:"), 0, 0);
        grid.add(param1, 1, 0);
        grid.add(value1, 2, 0);
        grid.add(unit1, 3, 0);
        grid.add(new Label("Param 2:"), 0, 1);
        grid.add(param2, 1, 1);
        grid.add(value2, 2, 1);
        grid.add(unit2, 3, 1);
        grid.add(calcBtn, 1, 2);
        grid.add(resultLabel, 1, 3, 3, 1);
        grid.add(backBtn, 1, 4);

        calcBtn.setOnAction(e -> {
            try {
                String p1 = param1.getValue();
                double v1 = Double.parseDouble(value1.getText());
                String u1 = unit1.getValue();
                String p2 = param2.getValue();
                double v2 = Double.parseDouble(value2.getText());
                String u2 = unit2.getValue();

                if (p1 == null || p2 == null || p1.equals(p2) || u1 == null || u2 == null) {
                    throw new Exception("Select two different parameters and units.");
                }

                String result = OhmCalculator.calculate(p1, v1, u1, p2, v2, u2);
                resultLabel.setText("Result: " + result);
                String inputs = p1 + "=" + v1 + u1 + ", " + p2 + "=" + v2 + u2;
                DBManager.saveCalculation(user, "Ohm", inputs, result);
            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Enter valid numerical values.");
                alert.show();
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, ex.getMessage());
                alert.show();
            }
        });

        backBtn.setOnAction(e -> MainMenuScene.show(stage, user));

        Scene scene = new Scene(grid, 500, 300);
        stage.setTitle("Ohm's Law Calculator");
        stage.setScene(scene);
        stage.show();
    }
}