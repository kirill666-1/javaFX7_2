package org.example.demo77;

public class Launcher {
    public static void main(String[] args) {
        // Главный класс, который вызывает launch()
        EngineeringCalculatorApp.main(args);
    }
}