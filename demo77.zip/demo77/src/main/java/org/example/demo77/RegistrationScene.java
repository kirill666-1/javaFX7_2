package org.example.demo77;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class RegistrationScene {
    public static void show(Stage stage) {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);

        Label userLabel = new Label("Username:");
        TextField userField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        Label roleLabel = new Label("Role:");
        ChoiceBox<String> roleChoice = new ChoiceBox<>();
        roleChoice.getItems().addAll("USER", "ADMIN");
        roleChoice.setValue("USER");
        Button regBtn = new Button("Register");
        Button backBtn = new Button("Back");

        grid.add(userLabel, 0, 0);
        grid.add(userField, 1, 0);
        grid.add(passLabel, 0, 1);
        grid.add(passField, 1, 1);
        grid.add(roleLabel, 0, 2);
        grid.add(roleChoice, 1, 2);
        grid.add(regBtn, 1, 3);
        grid.add(backBtn, 1, 4);

        regBtn.setOnAction(e -> {
            boolean success = DBManager.register(userField.getText(), passField.getText(), roleChoice.getValue());
            if (success) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Registered successfully");
                alert.show();
                LoginScene.show(stage);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Username exists or fields are empty");
                alert.show();
            }
        });

        backBtn.setOnAction(e -> LoginScene.show(stage));

        Scene scene = new Scene(grid, 400, 350);
        stage.setTitle("Register");
        stage.setScene(scene);
        stage.show();
    }
}