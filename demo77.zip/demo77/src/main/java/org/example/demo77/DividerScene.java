package org.example.demo77;

import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.Collectors;

public class DividerScene {
    public static void show(Stage stage, User user) {
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);

        // --- Controls for Input ---
        TextField vinField = new TextField("10");
        vinField.setPromptText("Vin (V)");
        TextField vreqField = new TextField("5");
        vreqField.setPromptText("Vreq (V)");
        TextField tolField = new TextField("1");
        tolField.setPromptText("Tolerance (%)");

        ChoiceBox<String> seriesChoice = new ChoiceBox<>(FXCollections.observableArrayList("E6", "E12", "E24", "E96"));
        seriesChoice.setValue("E12");

        TextField minRField = new TextField("100");
        minRField.setPromptText("Min R (Ohm)");
        TextField maxRField = new TextField("10000");
        maxRField.setPromptText("Max R (Ohm)");

        Button findBtn = new Button("Find Combinations");

        HBox inputFields = new HBox(10,
                new Label("Vin:"), vinField,
                new Label("Vreq:"), vreqField,
                new Label("Tolerance %:"), tolField,
                new Label("Series:"), seriesChoice
        );
        HBox rangeFields = new HBox(10,
                new Label("Min R:"), minRField,
                new Label("Max R:"), maxRField,
                findBtn
        );
        inputFields.setAlignment(Pos.CENTER_LEFT);
        rangeFields.setAlignment(Pos.CENTER_LEFT);

        // --- Table for Results ---
        TableView<DividerResult> table = new TableView<>();
        TableColumn<DividerResult, Integer> numCol = new TableColumn<>("Resistors");
        numCol.setCellValueFactory(new PropertyValueFactory<>("numRes"));
        TableColumn<DividerResult, String> configCol = new TableColumn<>("Config");
        configCol.setCellValueFactory(new PropertyValueFactory<>("config"));
        TableColumn<DividerResult, Double> voutCol = new TableColumn<>("Vout (V)");
        voutCol.setCellValueFactory(new PropertyValueFactory<>("vout"));
        TableColumn<DividerResult, Double> errorCol = new TableColumn<>("Error (%)");
        errorCol.setCellValueFactory(new PropertyValueFactory<>("error"));
        TableColumn<DividerResult, Double> powerCol = new TableColumn<>("Power (W)");
        powerCol.setCellValueFactory(new PropertyValueFactory<>("power"));

        table.getColumns().addAll(numCol, configCol, voutCol, errorCol, powerCol);

        // --- Schematic Canvas ---
        Canvas schematicCanvas = new Canvas(400, 200);

        // --- Buttons ---
        Button backBtn = new Button("Back");

        findBtn.setOnAction(e -> {
            try {
                double vin = Double.parseDouble(vinField.getText());
                double vreq = Double.parseDouble(vreqField.getText());
                double tol = Double.parseDouble(tolField.getText());
                String series = seriesChoice.getValue();
                double minR = Double.parseDouble(minRField.getText());
                double maxR = Double.parseDouble(maxRField.getText());

                List<DividerResult> results = VoltageDividerCalculator.findBestDividers(vin, vreq, tol, series, minR, maxR);
                table.getItems().setAll(results);

                // Save calculation (optional: save only the best result)
                if (!results.isEmpty()) {
                    DividerResult bestResult = results.get(0);
                    String inputs = String.format("Vin=%.1fV, Vreq=%.1fV, Tol=%.1f%%, Series=%s", vin, vreq, tol, series);
                    String resultText = String.format("Reds: %s, Vout=%.3fV, Error=%.3f%%", bestResult.getConfig(), bestResult.getVout(), bestResult.getError());
                    DBManager.saveCalculation(user, "Voltage Divider", inputs, resultText);
                }

            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Enter valid numerical values.");
                alert.show();
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, ex.getMessage());
                alert.show();
            }
        });

        table.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                drawSchematic(schematicCanvas, newVal);
            }
        });

        backBtn.setOnAction(e -> MainMenuScene.show(stage, user));

        vbox.getChildren().addAll(inputFields, rangeFields, table, schematicCanvas, backBtn);

        Scene scene = new Scene(vbox, 800, 600);
        stage.setTitle("Voltage Divider");
        stage.setScene(scene);
        stage.show();
    }

    private static void drawSchematic(Canvas canvas, DividerResult result) {
        // Простая схема для 2 резисторов (Vin -> R1 -> Vout -> R2 -> GND)
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(2);
        gc.setFill(Color.BLACK);

        double x = 100;
        double y = 50;

        // Линия Vin
        gc.strokeLine(x, 0, x, y);
        gc.fillText("Vin", x - 30, 10);

        // R_top
        gc.fillRect(x - 20, y, 40, 20); // Резистор
        gc.fillText(result.getResistors().stream().limit(result.getNumRes() / 2)
                .map(r -> String.format("%.0fΩ", r)).collect(Collectors.joining("+")), x + 30, y + 15);

        gc.strokeLine(x, y + 20, x, y + 70); // Соединение

        // Vout
        gc.strokeLine(x - 10, y + 70, x + 100, y + 70);
        gc.fillText("Vout", x + 110, y + 75);

        // R_bottom
        gc.strokeLine(x, y + 70, x, y + 120);
        gc.fillRect(x - 20, y + 120, 40, 20); // Резистор
        gc.fillText(result.getResistors().stream().skip(result.getNumRes() / 2)
                .map(r -> String.format("%.0fΩ", r)).collect(Collectors.joining("+")), x + 30, y + 135);

        // Линия GND
        gc.strokeLine(x, y + 140, x, y + 180);
        gc.strokeLine(x - 15, y + 180, x + 15, y + 180); // GND symbol
    }
}